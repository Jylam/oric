//
// This is the standard "HELLO WORLD" sample
//

#include <lib.h>

void main()
{
	printf("Hello World !\n");
}
