
// --------------------------------------
// OsdkSampleProject
// --------------------------------------
// (c) 2002 Mickael Pointier.
// This code is provided as-is.
// I do not assume any responsability
// concerning the fact this is a bug-free
// software !!!
// Except that, you can use this example
// without any limitation !
// If you manage to do something with that
// please, contact me :)
// --------------------------------------
// For more information, please contact me
// on internet:
// e-mail: mike@defence-force.org
// URL: http://www.defence-force.org
// --------------------------------------
// Note: This text was typed with a Win32
// editor. So perhaps the text will not be
// displayed correctly with other OS.

#include <lib.h>

#include "display.h"


void main()
{	
	printf("\r\nOsdkSampleProject");
	DisplayTest();
}










